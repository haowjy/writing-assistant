# Evaluation and Ablation Playbook

## 1. Two Separate Score Families

Maintain separate:

1. **Authoring Agent / Instruction Performance**
2. **Writing Artifact Performance**

Do not collapse them prematurely.

# Part I — Authoring Agent / Instruction Metrics

## 2. Operation Selection

Measure whether the model correctly identifies brainstorming, planning, critique, writing, revision, state update, tool lookup, or normal discussion. Use accuracy/F1.

## 3. Instruction Adherence

Measure explicit constraints such as POV, length, tone, scene goal, "do not reveal X," "keep Y," local-edit scope, and whether canon should be updated. Use constraint-level precision/recall/F1 plus hard violation rate.

## 4. Plan Adherence

Using required / optional / forbidden / deferred labels, measure required-beat coverage, forbidden-beat violation, deferred-information leakage, and unauthorized plot invention.

## 5. Tool Use

Measure tool validity, retrieval precision/recall, relevant-fact recall, unnecessary calls, duplicate reads, and robustness across file formats/tool schemas.

## 6. State Fidelity

Measure character knowledge, relationships, locations, inventory, chronology, unresolved threads, and canonical-state updates.

## 7. Edit Locality

When asked to change a small region, measure requested-change success and semantic preservation outside the edited span.

## 8. Multi-turn Retention

Construct conversations where early decisions are changed later and stale project files remain. Test whether the latest committed decision wins.

# Part II — Writing Artifact Metrics

## 9. N-Gram Token Distribution L2 Distance

Compare generated prose against a human reference corpus across multiple n-gram orders, scene types, and genres.

## 10. Maximum Mean Discrepancy (MMD)

Compute global and conditional MMD over prose embeddings. Keep it primarily evaluation-only at first.

## 11. Judge Model Quality (JMQ)

Apply JMQ only to the writing artifact, not the tool trace. Judge prose quality, coherence, characterization, pacing, dialogue, imagery, subtext, emotional credibility, and originality.

## 12. Diversity Growth / Semantic Tail

For the same state/instruction, sample many outputs and measure how collective semantic diversity grows with sample count. Plot `D(n)` and compare base, SFT, preference-trained, and RL models.

## 13. Redundancy and Over-Explanation

Measure semantic redundancy, repeated emotional beats, repeated exposition, duplicate narrative functions, and explicit statements of inferable information.

## 14. Surprise With Retrospective Justification

Rate predictability before the development and causal justification afterward. Desired behavior is low predictability + high retrospective justification.

# Part III — Diagnostic Ablations

## 15. If Prose Quality Does Not Improve After SFT

Ablate:
- target-corpus quality;
- scaffold quality;
- synthetic-prose ratio;
- LoRA rank/targets;
- LR/epochs;
- base vs instruction checkpoint.

## 16. If Instructions Improve but Writing Becomes Generic

Try:
- DFT-like distribution tuning;
- diversity-aware preference optimization;
- genre-balanced sampling;
- fewer SFT epochs;
- separate Writer LoRA;
- prose continued-pretraining before authoring SFT.

## 17. If Writing Improves but Instruction Following Gets Worse

Try:
- general-assistant replay;
- separate Writer and Agent adapters;
- lower rank;
- fewer steps;
- mode/operation conditioning.

## 18. If the Model Overuses Tools

Add no-tool examples, direct-response preference pairs, mild tool-cost rewards, and varied tool availability.

## 19. If the Model Underuses Tools

Remove duplicated context, create tasks impossible without retrieval, reward relevant-fact recall, increase retrieval examples, and reduce tool penalties.

## 20. If the Model Memorizes One Workflow

Randomize file layouts, tool availability, schemas/names, and valid trajectories. Include environments without search and environments requiring no tools.

## 21. If Multi-turn Conversations Fail

Increase medium/long trajectories, state-changing conversations, conversation windows, stale-state conflict examples, and external-state commits.

## 22. If Long Conversations Harm Writing Quality

Shorten visible history, summarize old conversation, retrieve compressed project state, separate Planner/Writer contexts, and feed Writer only a compact next-beat interface.

## 23. If the Writer Dumps Planning Into Prose

Hide planner scratchpad, use compressed EXPLICIT/IMPLICIT/DEFER interfaces, train leakage negatives, use stronger editor data, and optionally target leakage with RL.

## 24. If Planner/Writer Separation Produces Disjointed Prose

Give the writer more recent prose, enrich the interface, replan less often, write larger semantic beats, test unified LoRA, or let the writer request more context.

## 25. If Reasoning Between Paragraphs Makes Prose Choppy

Compare reasoning every paragraph, every ~400 words, every ~1000 words, semantic-beat boundaries, and learned STOP_AND_REPLAN.

## 26. If Planner Diversity Rises but Quality Falls

Use a quality threshold before diversity reward, lower diversity weight, branch first/rank later, or optimize event-level rather than lexical diversity.

## 27. If DFT Improves Distribution Metrics but Hurts Writing

Condition distribution matching by scene type/genre/operation, reduce distribution-loss weight, use stronger embeddings, or keep SFT/reward objectives jointly.

## 28. If GRPO Reward Rises but JMQ/Human Quality Falls

Assume reward hacking until proven otherwise. Inspect high-reward outputs, remove suspect reward dimensions, strengthen held-out evaluation, use reward ensembles, and prefer rule/structured rewards.

## 29. If Retrieval Improves but Writing Does Not

Run **oracle-context** tests. If writing succeeds with gold context, retrieval is the bottleneck. If writing still fails, the writer is the bottleneck. Also test selected-facts-only inputs and an explicit information-selection stage.

## 30. If Continuity Still Fails

Separate retrieval failure, reasoning failure, realization failure, and state-update failure. Ablate oracle state, richer state extraction, more state-update training, explicit character-knowledge files, timeline validation, smaller write chunks, and more frequent reasoning.

## 31. If New State Formats Fail

Increase format randomization, auxiliary conversion tasks, messy free-form notes, unseen tool schemas, and adversarial directory layouts.

## 32. If Unified LoRA Underperforms Specialists

Do not force consolidation. Compare unified LoRA, Planner+Writer, Planner+Writer+Editor, adapter switching, adapter fusion, and student distillation.

## 33. If Specialist Weight Merging Fails

Use runtime switching, routing by operation, adapter fusion, or distillation instead of naïve merging.

## 34. If Diffusion Does Not Improve Final Prose

Check whether it still improves semantic diversity, constraint reconciliation, or latent refinement. Test `AR planner → diffusion semantic refinement → AR writer` before discarding it.

# Part IV — Experimental Discipline

## 35. Fixed Core Evaluation Set

Never train on it. Include unseen synthetic worlds, private/unpublished stories, unseen tool layouts, long multi-turn sessions, explicit/implicit/deferred tests, plan-following tasks, revision tasks, and varied genres.

## 36. Archive Every Checkpoint

Record dataset version, seed, base checkpoint, LoRA config, objective, LR, steps, context-length mix, generation settings, and benchmark outputs.

## 37. Prefer Incremental Experiments

Do not change dataset, base model, objective, prompting, tool schema, and evaluation simultaneously.

## 38. Recommended Initial Matrix

| ID | Model | Training |
|---|---|---|
| A0 | Base IT | none |
| A1 | Base IT | unified SFT LoRA |
| A2 | Base IT | Planner SFT + base writer |
| A3 | Base IT | Planner SFT + Writer SFT |
| A4 | Base IT | Writer SFT only |
| A5 | A3 | + Editor pass |

Then:

| ID | Extension |
|---|---|
| B1 | Writer SFT → DFT-like tuning |
| B2 | Planner SFT → diversity preference training |
| B3 | Agent SFT → GRPO |
| B4 | Planner SFT → GRPO diversity |
| B5 | Writer targeted RL |
| C1 | diffusion realization comparison |
