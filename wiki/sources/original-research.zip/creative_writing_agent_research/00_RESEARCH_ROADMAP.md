# Creative Writing Authoring Agent — Research Roadmap

## 1. Project Goal

Build a **conversational authoring agent** that can collaborate with a writer over a long-running creative project.

The target is **not** simply a model that "writes good prose." The target is a model that can:

- understand multi-turn author instructions;
- inspect and reason over external project state;
- use generic file/tool interfaces;
- brainstorm and plan without prematurely converging;
- distinguish committed decisions from tentative discussion;
- write only the requested amount of prose;
- preserve information that should remain implicit or deferred;
- revise locally without unnecessarily rewriting unrelated text;
- maintain story continuity across long projects;
- think/reason between writing chunks;
- update external state after writing or planning decisions.

The persistent project may be much larger than the model's context window. The model should rely on an **external authoring workspace** rather than attempting to keep the entire novel in context.

## 2. Core System Model

```text
user instruction
    ↓
inspect conversational context
    ↓
decide whether tool use is needed
    ↓
retrieve relevant project state
    ↓
reason / plan locally
    ↓
decide explicit vs implicit vs deferred information
    ↓
write the next semantic beat / passage
    ↓
observe what was actually written
    ↓
update story state / plan if needed
    ↓
repeat
```

The visible output may be a paragraph, scene, chapter section, or complete chapter, but internally the system should be capable of **interleaving reasoning and realization** rather than performing one long uninterrupted decode.

## 3. Persistent Authoring Workspace

The model should not depend on one canonical story-state format. Training and evaluation should include variation across Markdown wikis, YAML state files, JSON records, CSV timelines, plain-text notes, mixed-format repositories, sparse or messy folders, stale or conflicting notes, and raw prior chapters.

The desired capability is **semantic state use**, not memorization of a particular file organization.

## 4. Initial Model Strategy

Use a strong **instruction-tuned 7B–12B conversational model** as the base. The fine-tune should mostly alter the **authoring policy**, not teach file formats or conversation from scratch.

Start with:

```text
instruction-tuned base
        ↓
QLoRA SFT
```

Do **not** start with GRPO. First establish that the dataset and adapter can teach the desired behavior at all.

After SFT:

```text
SFT
├── prose distribution tuning / preference tuning
├── planner diversity tuning
└── targeted RL for measurable agent behaviors
```

Diffusion should initially be treated as an **architecture ablation**, not the foundation of the system.

## 5. Specialist Capabilities

Initial experiments should test whether these capabilities should be one unified LoRA or separate adapters/models:

### Authoring Agent / Planner
- understand user intent;
- decide whether to brainstorm, plan, edit, write, or update state;
- inspect project files;
- reason causally;
- generate and compare alternatives;
- construct the next semantic writing beat.

### Retriever
- decide whether lookup is necessary;
- choose useful files/tools;
- avoid retrieving the entire project;
- reconcile duplicated or conflicting state.

### Writer / Realizer
- realize a known local plan as prose;
- follow constraints;
- avoid inventing unnecessary plot information;
- maintain subtext and restraint;
- expose only information that belongs on the page.

### Observer / State Updater
- inspect newly written prose;
- determine what became canonical;
- update character/world/timeline/plot state;
- detect deviations from the previous plan.

### Editor
- remove redundancy;
- remove unnecessary explanation;
- remove irrelevant lore/context;
- preserve meaningful atmosphere and pacing;
- make narrow edits locally.

## 6. Training Stages

### Phase 0 — Infrastructure and Baselines
Build the inference harness, tool simulator, project-filesystem environment, prompt suite, reproducible generation settings, and evaluation harness. Evaluate the untouched base model before tuning.

### Phase 1 — Dataset Construction
Construct multi-turn authoring-agent trajectories from public-domain/permissively licensed fiction, author-contributed material, personal planning histories, and synthetic story worlds. Synthetic generation should primarily create project files, plans, user instructions, tool trajectories, hidden reasoning scaffolds, state updates, alternative plans, and editing corruptions. Prefer **human-written prose as the final target** wherever possible.

### Phase 2 — SFT QLoRA
Train the first authoring-agent adapter. Test both one combined Authoring-Agent LoRA and separate Agent/Planner + Writer LoRAs.

### Phase 3 — Prose Distribution Optimization
Compare base, SFT, SFT→DFT-like distribution tuning, and preference optimization. Goal: reduce stereotyped LLM prose while preserving instruction and plan adherence.

### Phase 4 — Planner Diversity Optimization
Compare diverse preference optimization, creativity-focused preference optimization, explicit branching/search, and group-relative RL.

### Phase 5 — Targeted Agent RL
Use RL only for properties with relatively objective rewards: operation selection, tool-call validity, retrieval precision/recall, plan adherence, continuity, forbidden-information leakage, state-update correctness, and tool efficiency.

### Phase 6 — Continual Authoring Loop
Compare `retrieve → reason → write beat → observe → update → repeat` against `retrieve once → write whole chapter`.

### Phase 7 — Diffusion Ablations
Only after the AR pipeline is understood, compare AR writer, diffusion writer, and diffusion semantic refinement followed by AR prose realization.

## 7. Primary Research Questions

1. Can a small LoRA turn a capable general assistant into a materially better authoring collaborator without harming general abilities?
2. Does explicit external project state improve long-horizon coherence?
3. Does interleaving reasoning between writing chunks outperform single-pass chapter generation?
4. Should planner and writer behaviors be trained separately?
5. Can the model reason expansively while writing selectively?
6. Does distribution-focused fine-tuning reduce stereotyped LLM prose beyond SFT?
7. Which objective best improves meaningful creative diversity?
8. Can targeted RL improve agent behavior without degrading prose?
9. Does environment randomization improve generalization to unseen project layouts?
10. Does diffusion improve writing when isolated as a realization/refinement component?

## 8. Success Criteria

Report **Authoring Agent Performance** and **Writing Artifact Performance** separately. Do not let beautiful prose hide poor instruction following, or perfect obedience hide boring writing.
