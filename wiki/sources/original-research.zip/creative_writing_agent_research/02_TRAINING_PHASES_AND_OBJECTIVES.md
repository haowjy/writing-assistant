# Training Phases and Objectives

## 1. Principle

Do not jump directly to RL. The staged program should answer whether supervised adaptation is enough, which failures are distributional versus procedural, and which remaining behaviors have rewards reliable enough for RL.

## 2. Stage 0 — Untuned Baseline

Evaluate the untouched instruction-tuned base on both agent/instruction and writing metrics. Archive all generations.

## 3. Stage 1 — SFT QLoRA

### Variant A — Unified Authoring-Agent LoRA
Train one adapter on planning, tool use, prose, revision, and state updates.

### Variant B — Split Planner + Writer

```text
Planner/Agent LoRA
    ↓
compressed next-beat interface
    ↓
Writer LoRA
```

### Variant C — Planner + Writer + Editor
Add a separate editing pass and measure whether it adds value beyond a better writer.

## 4. Stage 2 — Prose Distribution Training

Compare:

```text
SFT only
SFT → DFT-like distribution tuning
SFT → DPO/ORPO
SFT → diversity-aware preference tuning
```

Goal: lower human/model distribution discrepancy without sacrificing plan adherence.

## 5. Stage 3 — Planner Diversity Training

Test preference optimization over diverse/high-quality plans, explicit branching, group-relative rewards, and novelty-aware ranking. Do not reward novelty alone; use a quality threshold.

## 6. Stage 4 — Agent GRPO / RL

Use RL first where signals are objective or semi-objective:

- tool-call validity;
- retrieval quality;
- instruction compliance;
- plan adherence;
- state consistency;
- state-update quality;
- forbidden-information leakage;
- modest tool-efficiency penalties.

Task success should dominate so the model does not learn to avoid tools.

## 7. Stage 5 — Writer RL, Only If Necessary

Use writer RL only for specific residual failures that can be measured reliably, such as leakage, plan violations, repetition, semantic redundancy, recap, length errors, and continuity errors.

Avoid initially optimizing vague scalar rewards like creativity or literary quality.

## 8. Stage 6 — Interleaved Reasoning

Compare:

```text
A. plan once → whole chapter
B. reason every ~1000 words
C. reason every ~400 words
D. reason at semantic beat boundaries
E. model chooses CONTINUE vs STOP_AND_REPLAN
```

Measure coherence, plan adherence, pacing, repetition, stylistic fragmentation, continuity, and completion.

## 9. Stage 7 — Reasoning Visibility

Compare writer inputs:

- full planner scratchpad;
- compressed interface with NEXT BEAT / EXPLICIT / IMPLICIT / DEFER / AVOID;
- event only.

Hypothesis: compressed interfaces reduce analytical language leaking into prose.

## 10. Stage 8 — Tool-Policy Generalization

Vary tools available, tool names, schemas, file formats, directory structures, noise ratio, and stale/contradictory state. Reward outcomes rather than exact action sequences.

## 11. Stage 9 — Diffusion Ablation

Compare AR planner→AR writer, AR planner→diffusion writer, and AR planner→diffusion semantic refinement→AR writer while holding data/prompts/evaluation fixed.

## 12. Stage 10 — Distillation / Consolidation

Only after specialist behaviors are understood, test LoRA merging, adapter fusion, runtime switching, multitask student distillation, or keeping specialists permanently. Do not assume one model is the optimal endpoint.

## 13. General Capability Preservation

After each major stage, test ordinary instruction following, QA, summarization, coding, conversation, structured output, and non-fiction tool calling.

## 14. Recommended First Experiment

Before RL:

```text
Base IT baseline
vs
Unified SFT LoRA
vs
Planner SFT + Writer SFT
```

If this does not produce measurable gains, debug data and architecture before introducing GRPO.

## 15. Recommended Objective Order

```text
SFT
  ↓
distribution / preference optimization
  ↓
targeted agent RL
  ↓
targeted planner RL
  ↓
writer RL only for measurable residual errors
```
